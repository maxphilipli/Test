/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

/**
 *
 * @author MaxLi
 */
public class FXMLDocumentController {
    
    public void GoButtonClicked(){
        System.out.println("God damn I'm sexy");
    }
    
    public void SubmitButtonClicked() {
        System.out.println("This button doesn't do anything yet besides print this message. Fooled you!");
    }
}
 
